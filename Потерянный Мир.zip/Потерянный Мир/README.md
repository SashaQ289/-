# TestPlanetMindustry
### Russian
Привет, этот репозиторий - исходный файл с видео туториала на Youtube. Здесь будет находится весь исходный код тестовой планеты.
Если захотите, тогда я могу помочь сделать не только планету, но и секторы к ней, а также генерацию секторов. Всё зависит только от вас.

Скорее всего я заброшу видосы по этому репозиторию т.к туториалы набирают мало просмотров (например на последнем туториале собрало 100 с чем то просмотров, хотя показов было 17000! (и больше)), но если вы меня упросите в дискорде, тогда я продолжу над ним работу, но без роликов (думаю, после тех туториалов вы уже не дурачки, которые не поймут как скопировать и вставить код ] )

### English
Hello, this repository is the source file of the tutorial video on Youtube. All the source code for the test planet will be located here.
If you want, then I can help make not only the planet, but also the sectors to it, as well as the generation of sectors. Everything depends on you.

Most likely, I will abandon videos on this repository because tutorials get few views (for example, the last tutorial collected 100-odd views, although there were 17,000 impressions! (and more)), but if you ask me in discord, then I will continue work, but without videos (I think after those tutorials you are no longer fools who won’t understand how to copy and paste the code ] )

[![Stars](https://img.shields.io/github/stars/Lehanchic25/TestPlanetMindustry?color=7289da&label=⭐️%20Please%20Star%20This%20Tutorial%21)](https://github.com/Lehanchic25/TestPlanetMindustry)
[![Download](https://img.shields.io/github/v/release/Lehanchic25/TestPlanetMindustry?color=6aa84f&include_prereleases&label=Latest%20version&logo=github&logoColor=white&)](https://github.com/Lehanchic25/TestPlanetMindustry/releases)[![Total Downloads](https://img.shields.io/github/downloads/Lehanchic25/TestPlanetMindustry/total?color=7289da&label&logo=docusign&logoColor=white)](https://github.com/Lehanchic25/TestPlanetMindustry/releases)
